# TaxWise India

Professional Indian Tax & Advance Tax Calculator for Investors.

## Features
- **AI-Powered Parsing**: Upload P&L statements, e-CAS, and foreign asset records.
- **Tax Engine**: Automated calculation of STCG and LTCG based on latest Indian laws.
- **Advance Tax Schedule**: Precise payment schedule to avoid interest penalties.
- **Interactive Dashboard**: Visual distribution of income and tax liability.

## Tech Stack
- **Frontend**: React, TypeScript, Tailwind CSS, shadcn/ui
- **State Management**: Zustand
- **Charts**: Recharts
- **AI**: Gemini 3.1 Pro
- **Backend**: Express (for API routing)

## Getting Started
1. Clone the repository.
2. Install dependencies: `npm install`
3. Set up environment variables in `.env`.
4. Run development server: `npm run dev`
